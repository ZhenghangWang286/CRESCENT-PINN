# Licensing status

No open-source licence is specified for this release.

NumPy and SciPy are installed separately and retain their respective licences.
