# CRESCENT: reusable field corrections

Numerical software and research data accompanying
*A transferable memory of physical responses for scientific computing*.

CRESCENT constructs source responses, solves constrained queries in a reusable
coefficient space, applies independent physics acceptance, enriches the response
basis with accepted corrections, and integrates reduced thermal systems.

## Quick start

Use Python 3.12. All commands run on a CPU with NumPy and SciPy.
From the extracted `CRESCENT` directory, create a virtual environment:

```bash
python -m venv .venv
```

Activate the environment for your shell:

| Shell | Command |
|---|---|
| Windows PowerShell | `.\.venv\Scripts\Activate.ps1` |
| Windows Command Prompt | `.venv\Scripts\activate.bat` |
| macOS / Linux | `source .venv/bin/activate` |

Install the pinned dependencies and run the repository:

```bash
python -m pip install -r requirements.txt
python run_all.py
```

`run_all.py` verifies the release checksums, runs the numerical and data tests,
and executes all five programs below. It exits with a nonzero status if a check
or program fails. Dependency installation requires access to a package index;
the calculations use the code and data in this repository and run offline.

## Programs

Run each program from the repository root:

| Command | Calculation |
|---|---|
| `python -m scripts.reuse_query` | Affine constraints, query acceptance, exact reversion and accepted-direction enrichment |
| `python -m scripts.source_responses` | Ten source-response columns, normalized SVD basis and finite-difference verification |
| `python -m scripts.thermal_recurrence` | Thermal time integration and comparison with direct implicit Euler |
| `python -m scripts.frozen_bank` | Reconstruction of stored query coefficients in the 480-coefficient, 69-direction thermal bank |
| `python -m scripts.summarize_results` | Statistics computed from the manuscript measurement tables |

The source-response, constrained-query and thermal-recurrence programs assemble
their operators in code. The bank and statistics programs read the arrays and
measurements in `datasets/`.

## Repository contents

| Location | Contents |
|---|---|
| `crescent/responses.py` | Equilibrated QR source solves, source sensitivities and normalized SVD banks |
| `crescent/reuse.py` | Affine reconstruction, checked reduced queries and fieldwise enrichment |
| `crescent/thermal.py` | Global QR and mass-scaled implicit-Euler recurrence |
| `scripts/` | Executable calculations and data analyses |
| `datasets/` | Measurement tables, thermal bases, query states and data manifest |
| `tests/` | Numerical identities, acceptance and reversion, input checks and data consistency |
| `documentation/` | Numerical methods, paper-to-code map and verification instructions |
| `run_all.py` | Checksum verification, test suite and program runner |

## Research data

The thermal-transfer table contains 60 records spanning 12 conditions and five
methods. The thermal workload contains five sampling realizations, three
methods and 500 conditions per realization and method, for 7,500
method-query-realization evaluations.

The data documentation defines observation units, condition roles, method
labels, field differences, physics residuals and timing boundaries. The data
manifest records dataset checksums, table schemas and figure associations.

## Documentation

- [Numerical methods](documentation/methods.md)
- [Paper-to-code map](documentation/manuscript.md)
- [Research data](datasets/README.md)
- [Verification](documentation/validation.md)
- [Citation](CITATION.md)
- [Rights and dependencies](RIGHTS.md)
