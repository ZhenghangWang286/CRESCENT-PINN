# Numerical methods

## Source responses

For a tall full-rank residual operator, the source coefficients satisfy

    A.T @ (A @ c - b) = 0.

For an operator derivative dA and source derivative db,

    (A.T @ A) @ dc = A.T @ (db - dA @ c) - dA.T @ (A @ c - b).

The adjoint-residual term is retained even when the source least-squares
problem is inconsistent. `SourceFactor` applies the inverse through
column-equilibrated QR factors, without forming `A.T @ A`.

`thermal_columns` assumes that the operator is affine in conductivity and
velocity scale, while the right-hand side depends on source position. It
returns the columns in the order

    c, c_kappa, c_x, c_kappa_kappa, c_kappa_x, c_x_x,
    c_s, c_s_s, c_kappa_s, c_x_s.

`response_basis` normalizes each nonzero column and retains singular values
strictly greater than `rtol * largest_singular_value`. The default cutoff is
1e-12. SVD signs are arbitrary; compare subspaces or reconstructed states
rather than signed columns.

## Query and acceptance

The field is represented as

    q = lift + Z @ (anchor + V @ beta),
    C @ lift = prescribed,    C @ Z = 0.

For the linear kernel, `beta` minimizes the column-equilibrated system
`(A @ V) @ beta = b - A @ anchor`. `solve_query` then calls a supplied
independent physics gate on the candidate free coefficients. Rejection
returns the original anchor exactly. Applications supply the field
reconstruction and the gate's geometry-specific residual evaluation.

The query example uses independent algebraic equations for acceptance.
Reference-based field evaluation is performed separately from response-space
construction and physics acceptance.

## Accepted-state promotion

An accepted increment is partitioned into fields. Each part is projected
twice against the existing orthonormal library. Nontrivial orthogonal parts
are SVD-orthogonalized, truncated to the rank budget, projected twice again,
and QR-normalized. Existing columns remain unchanged. Both solve and validation
checks must pass before enrichment. After adding directions, applications
extend or rebuild the projected operators for the updated basis.

## Transient thermal recurrence

For mass matrix M = diag(mass), stiffness L and forcing P @ u,

    M @ (T[j] - T[j-1]) / dt + L @ T[j] = P @ u[j].

The exact initial lift is T0. With y = sqrt(M) @ (T - T0),

    S = I + dt * invsqrt(M) @ L @ invsqrt(M),
    F = dt * invsqrt(M) @ [P, -L @ T0].

A global QR of the supplied space gives Q. Diagonalizing `Q.T @ S @ Q`
gives a rotated basis R and eigenvalues e. The reduced coefficients obey

    z[0] = 0,
    z[j] = (z[j-1] + R.T @ F @ [u[j], 1]) / e,
    T[j] = T0 + invsqrt(M) @ R @ z[j].

The source response space is reused across forcing histories. Each call
integrates the supplied forcing sequence using the cached reduced operators.
The interface accepts dense assembled thermal matrices and a response basis.
