# Verification

The verification environment is Windows with Python 3.12.14, NumPy 2.3.5 and
SciPy 1.17.0. Dependency versions are pinned in `requirements.txt`.

## Run all checks and programs

After installing the dependencies, run:

```bash
python run_all.py
```

The runner checks the files listed in `SHA256SUMS.txt`, executes the test suite,
then runs the five programs in `scripts/`. It prints the environment versions
and stops with a nonzero exit status on failure. It resolves the repository
directory from its own path, so it can also be invoked from another directory.

## Numerical and data tests

Run the tests separately from the repository root:

```bash
python -m unittest discover -s tests -v
```

The 43 tests cover:

- source solves against an independent least-squares calculation;
- first and mixed second responses against finite differences, including the
  adjoint-residual contribution;
- normalized-bank rank selection and input validation;
- affine constraints, query acceptance and exact reversion;
- fieldwise enrichment, preservation of existing columns and rank limits;
- thermal recurrence against direct implicit Euler and Galerkin identities;
- data checksums, comparison sets, metric definitions and paired statistics.

## Executable calculations

```bash
python -m scripts.reuse_query
python -m scripts.source_responses
python -m scripts.thermal_recurrence
python -m scripts.frozen_bank
python -m scripts.summarize_results
```

The first three programs compute solutions from their assembled operators and
check the resulting numerical identities. The bank program checks coefficient
reconstruction and basis orthogonality. The statistics program computes JSON
summaries from the measurement tables. Both data programs verify the dataset
checksums before reading the measurements.

## File integrity

`SHA256SUMS.txt` lists the SHA-256 hash of each distributed repository file
except the checksum file itself. `datasets/manifest.json` records the checksums,
schemas and figure associations of the 14 dataset files. The `.gitattributes`
file fixes text line endings to LF and keeps NumPy archives binary.
