# Paper-to-code map

The table connects manuscript methods and datasets to their Python interfaces
and executable calculations.

| Manuscript component | Interface or command | Computation |
|---|---|---|
| Admissible field directions; Methods: Admissible residual correction | `admissible_state`, `solve_query` | Verify an affine constraint map and solve a linear query with an independent acceptance gate |
| Fig. 1; Methods: Frozen thermal transfer protocol | `SourceFactor.thermal_columns`, `response_basis` | Construct ten response columns from an affine source operator and form a normalized SVD basis |
| Figs. 1-2: 480-coefficient, 69-direction thermal bank | `python -m scripts.frozen_bank` | Reconstruct stored query coefficients from the archived bank and check orthogonality |
| Fig. 3d; Methods: Magnetohydrodynamic correction | `promote_accepted` | Enrich a basis through field-split SVD of an accepted increment |
| Fig. 4; Methods: Transient operators and statistics | `ThermalROM` | Integrate dense thermal operators in a supplied response space using reduced implicit Euler |
| Numerical records for Figs. 1-4 | `python -m scripts.summarize_results` | Calculate descriptive statistics from the archived measurement tables |

## Operator interfaces

`SourceFactor` takes an assembled, full-column-rank residual operator.
`solve_query` takes an assembled query operator, right-hand side, anchor,
orthonormal response basis and physics gate. `admissible_state` reconstructs
fields from a lift and null map. Applications assemble geometry-specific
operators and reference fields for these interfaces.

`promote_accepted` takes an increment that has passed the solve and validation
checks. `ThermalROM` takes dense mass, stiffness and port operators, an initial
temperature, a time step and a response basis. Its time loop evaluates the
diagonal reduced recurrence described in [Numerical methods](methods.md).

## Executable calculations

`scripts.reuse_query` checks affine constraints, query acceptance, exact
reversion and accepted-direction promotion. `scripts.source_responses`
checks source sensitivities against finite differences.
`scripts.thermal_recurrence` compares a two-cell thermal calculation with
direct implicit Euler.

`scripts.frozen_bank` reconstructs coefficients from stored arrays.
`scripts.summarize_results` reads recorded measurements and computes their
statistics. Dataset and timing definitions are given in the
[data documentation](../datasets/README.md).

## Thermal bank and query states

`thermal_bank.npz` stores the CRESCENT, matched-QR, no-response and no-gate
bases. The query-5 archives store candidate and returned coefficients for
five methods. The CSV tables contain method comparisons and their numerical
measurements; `datasets/manifest.json` records file checksums, column names and
manuscript figure associations.
