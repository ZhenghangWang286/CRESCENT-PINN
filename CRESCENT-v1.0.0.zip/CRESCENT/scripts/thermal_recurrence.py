"""Two-cell thermal recurrence with an independently solved comparator."""

import numpy as np

from crescent import ThermalROM


def main():
    mass = np.array([2., 3.])
    stiffness = np.array([[3., -1.], [-1., 2.]])
    ports = np.array([[2.], [1.]])
    initial = np.array([20., 21.])
    dt = .1
    inputs = np.array([[0.], [1.], [1.], [.5], [0.]])
    basis = np.array([[1., 1.], [0., 1.]])
    rom = ThermalROM(mass, stiffness, ports, initial, dt, basis)
    temperatures = rom.solve(inputs)
    direct = np.empty_like(temperatures)
    direct[0] = initial
    system = np.diag(mass / dt) + stiffness
    for j in range(1, len(inputs)):
        direct[j] = np.linalg.solve(system, mass / dt * direct[j - 1] + ports @ inputs[j])
    np.testing.assert_allclose(temperatures, direct, atol=1e-12, rtol=1e-12)
    np.testing.assert_array_equal(temperatures[0], initial)
    print("Two-cell thermal recurrence")
    print(f"Maximum discrepancy from direct implicit Euler: {np.max(np.abs(temperatures - direct)):.3e} K")
    print("Initial temperature and direct implicit-Euler agreement verified.")


if __name__ == "__main__":
    main()
