"""Ten-column source-response construction and finite-difference verification."""

import numpy as np

from crescent import SourceFactor, response_basis


def main():
    rng = np.random.default_rng(19)
    a = rng.normal(size=(24, 16))
    ak = .05 * rng.normal(size=a.shape)
    av = .05 * rng.normal(size=a.shape)
    b0, bx, bxx = rng.normal(size=(3, a.shape[0]))
    factor = SourceFactor(a)
    columns = factor.thermal_columns(b0, ak, av, bx, bxx)
    basis, spectrum = response_basis(columns)
    step = 1e-5
    plus = np.linalg.lstsq(a + step * ak, b0, rcond=None)[0]
    minus = np.linalg.lstsq(a - step * ak, b0, rcond=None)[0]
    difference = np.linalg.norm((plus - minus) / (2 * step) - columns[:, 1])
    np.testing.assert_allclose((plus - minus) / (2 * step), columns[:, 1], atol=1e-8, rtol=1e-7)
    print("Source-response construction: 24 equations, 16 coefficients")
    print(f"Source columns: {columns.shape[1]}; retained rank: {basis.shape[1]}")
    print(f"First-response finite-difference discrepancy: {difference:.3e}")
    print(f"Smallest scaled-bank singular value: {spectrum[-1]:.3e}")


if __name__ == "__main__":
    main()
