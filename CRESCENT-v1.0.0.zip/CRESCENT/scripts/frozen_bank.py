"""Reconstruct a thermal query state and check response-bank orthogonality."""

from pathlib import Path

import numpy as np

from .summarize_results import verify_data


DATA = Path(__file__).resolve().parents[1] / "datasets"


def main():
    verify_data()
    with np.load(DATA / "thermal_bank.npz", allow_pickle=False) as bank:
        basis = bank["crescent"]
        qr_basis = bank["classical_same_info"]
    with np.load(DATA / "thermal_query_5_crescent.npz", allow_pickle=False) as state:
        coefficients = state["returned"]
    coordinates = basis.T @ coefficients
    discrepancy = np.linalg.norm(coefficients - basis @ coordinates) / np.linalg.norm(coefficients)
    orthogonality = np.max(np.abs(basis.T @ basis - np.eye(basis.shape[1])))
    subspace_gap = np.linalg.norm(basis - qr_basis @ (qr_basis.T @ basis))
    if discrepancy > 1e-10 or orthogonality > 1e-10:
        raise RuntimeError("stored coefficients and bank do not agree")
    print("Thermal response bank and stored-state reconstruction")
    print(f"Bank: {basis.shape[0]} coefficients x {basis.shape[1]} retained directions")
    print(f"Stored-state reconstruction discrepancy: {discrepancy:.3e}")
    print(f"Bank orthogonality discrepancy: {orthogonality:.3e}")
    print(f"SVD/QR truncated-subspace Frobenius discrepancy: {subspace_gap:.5f}")
    print("Query 5 is the first of eight prospective conditions.")


if __name__ == "__main__":
    main()
