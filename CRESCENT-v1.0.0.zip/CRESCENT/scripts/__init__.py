"""Run CRESCENT programs from the repository root with python -m scripts.<name>."""
