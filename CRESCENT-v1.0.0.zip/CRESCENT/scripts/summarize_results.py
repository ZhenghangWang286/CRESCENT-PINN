"""Compute manuscript statistics from the measurement tables."""

import csv
import hashlib
import json
from pathlib import Path

import numpy as np


DATA = Path(__file__).resolve().parents[1] / "datasets"


def verify_data():
    manifest = json.loads((DATA / "manifest.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        path = DATA / item["file"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
            raise ValueError(f"data checksum mismatch: {item['file']}")
    return len(manifest["files"])


def rows(name):
    with (DATA / name).open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def paired(table, unit, method, value, numerator, denominator):
    grouped = {}
    for row in table:
        key = row[unit]
        label = row[method]
        values = grouped.setdefault(key, {})
        if label in values:
            raise ValueError(f"duplicate paired observation: {key}, {label}")
        values[label] = float(row[value])
    ratios = []
    for key, values in sorted(grouped.items()):
        a, b = values[numerator], values[denominator]
        if not np.isfinite([a, b]).all() or min(a, b) <= 0:
            raise ValueError(f"invalid paired values: {key}")
        ratios.append(a / b)
    return np.asarray(ratios)


def summarize():
    verify_data()
    transfer = rows("thermal_transfer.csv")
    prospective = [r for r in transfer if r["role"] == "prospective"]
    factors = paired(prospective, "query_id", "method", "max_field_relative_l2", "no_operator", "crescent")
    workload = rows("thermal_workload.csv")
    ratios = paired(workload, "seed", "method", "complete_process_s", "fast_qr", "projected_guarded")
    contact = rows("thermal_contact.csv")
    mhd = rows("mhd_timing.csv")
    continuation = rows("mhd_continuation.csv")
    thermal = rows("transient_thermal.csv")

    def medians(table, key, value):
        return {
            method: float(np.median([float(r[value]) for r in table if r[key] == method]))
            for method in sorted({r[key] for r in table})
        }

    return {
        "source": "archived manuscript measurements",
        "thermal_transfer": {
            "method_query_records": len(transfer),
            "prospective_conditions": len({r["query_id"] for r in prospective}),
            "crescent_max_fieldwise_relative_l2": max(
                float(r["max_field_relative_l2"]) for r in transfer if r["method"] == "crescent"
            ),
            "prospective_no_response_over_crescent_median": float(np.median(factors)),
            "all_methods_field_target_pass_counts": {
                name: sum(r["field_target_pass"] == "True" for r in transfer if r["method"] == name)
                for name in sorted({r["method"] for r in transfer})
            },
        },
        "thermal_workload": {
            "sampling_realizations": len(ratios),
            "queries_per_realization_per_method": 500,
            "method_query_realization_records": sum(int(r["n_queries"]) for r in workload),
            "mean_paired_complete_process_speedup": float(np.mean(ratios)),
            "sample_sd_paired_speedup": float(np.std(ratios, ddof=1)),
        },
        "contact_median_history_inclusive_seconds": medians(contact, "method", "history_inclusive_service_s"),
        "mhd_median_external_process_seconds": medians(mhd, "method", "external_process_s"),
        "mhd_cumulative_service_at_query_12_seconds": {
            r["method"]: float(r["cumulative_service_s"])
            for r in continuation if int(r["total_service_queries"]) == 12
        },
        "transient_three_dimensional_cases": [
            {key: r[key] for key in ("scenario", "branch", "N", "K", "online_s", "cold_s",
                                     "same_grid_relative_l2", "gate_pass")}
            for r in thermal if r["dimension"] == "3"
        ],
    }


def main():
    print(json.dumps(summarize(), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
