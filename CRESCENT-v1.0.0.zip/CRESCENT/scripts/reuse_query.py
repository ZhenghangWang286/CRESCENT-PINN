"""Constrained query, independent acceptance, and response-space enrichment."""

import numpy as np

from crescent import admissible_state, promote_accepted, response_basis, solve_query


def main():
    columns = np.array([[1., 0.], [1., 0.], [0., 1.], [0., 1.]])
    basis, _ = response_basis(columns)
    a = np.array([[2., 1., 0., 1.], [0., 2., 1., 0.],
                  [1., 0., 3., 1.], [0., 1., 1., 2.], [1., 0., 0., 1.]])
    held = np.array([[1., 2., 0., 1.], [0., 1., 3., 2.], [1., 0., 1., 2.]])
    anchor = np.zeros(4)
    prescribed_coefficients = columns @ np.array([.4, -.2])
    rhs = a @ prescribed_coefficients
    held_rhs = held @ prescribed_coefficients
    gate = lambda c: bool(np.max(np.abs(held @ c - held_rhs)) <= 1e-12)
    result = solve_query(a, rhs, anchor, basis, gate)
    if not result.accepted:
        raise RuntimeError("query failed its independent acceptance equations")
    constraint = np.array([[1., 0., 0., 0., 0., 0.],
                           [0., 0., 0., 0., 0., 1.]])
    lift = np.array([2., 0., 0., 0., 0., 3.])
    null_map = np.eye(6)[:, 1:5]
    field = admissible_state(lift, null_map, result.state, constraint, [2., 3.])
    rejected = solve_query(a, rhs, anchor, basis, lambda c: False)
    np.testing.assert_array_equal(rejected.state, anchor)
    increment = np.array([1., -1., 2., -2.])
    extended, added = promote_accepted(
        basis, increment, [2, 2], solve_pass=True, validation_pass=True,
        max_rank=4, max_new=2,
    )
    print("Constrained query and accepted-direction promotion")
    print(f"Free coefficients: 4; initial response rank: {basis.shape[1]}")
    print(f"Accepted: {result.accepted}; exact revert checked: {not rejected.accepted}")
    print(f"Constraint discrepancy: {np.max(np.abs(constraint @ field - [2., 3.])):.3e}")
    print(f"Accepted-direction update: +{added}; new rank: {extended.shape[1]}")


if __name__ == "__main__":
    main()
