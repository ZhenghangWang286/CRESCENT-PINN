"""Verify file integrity, run the tests, and execute the CRESCENT programs."""

import hashlib
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
PROGRAMS = (
    "scripts.reuse_query",
    "scripts.source_responses",
    "scripts.thermal_recurrence",
    "scripts.frozen_bank",
    "scripts.summarize_results",
)


def verify_release():
    """Check every file listed in the release checksum manifest."""
    count = 0
    for line in (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT):
            raise ValueError(f"invalid checksum path: {name}")
        if not path.is_file():
            raise ValueError(f"release file missing: {name}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f"release checksum mismatch: {name}")
        count += 1
    if count == 0:
        raise ValueError("release checksum manifest is empty")
    return count


def main():
    try:
        import numpy
        import scipy
    except ImportError as error:
        print(f"Dependency import failed: {error}", file=sys.stderr)
        print("Install dependencies with: python -m pip install -r requirements.txt",
              file=sys.stderr)
        return 1

    print(f"Python {sys.version.split()[0]} | NumPy {numpy.__version__} | "
          f"SciPy {scipy.__version__}", flush=True)
    try:
        count = verify_release()
    except (OSError, ValueError) as error:
        print(f"File verification failed: {error}", file=sys.stderr)
        return 1
    print(f"Release checksums verified: {count} files", flush=True)

    commands = [
        ("Numerical and data tests", ["-m", "unittest", "discover", "-s", "tests", "-v"]),
        *((program, ["-m", program]) for program in PROGRAMS),
    ]
    for label, arguments in commands:
        print(f"\nRunning {label}", flush=True)
        result = subprocess.run([sys.executable, "-B", "-u", *arguments], cwd=ROOT)
        if result.returncode:
            print(f"Failed: {label} (exit status {result.returncode})", file=sys.stderr)
            return result.returncode
    print("\nAll tests and five programs completed successfully.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
