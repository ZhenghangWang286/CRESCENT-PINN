import unittest

import numpy as np

from scripts.summarize_results import DATA, paired, rows, summarize, verify_data


class FrozenDataTests(unittest.TestCase):
    def test_all_data_checksums(self):
        self.assertEqual(verify_data(), 14)

    def test_transfer_comparison_is_complete(self):
        table = rows("thermal_transfer.csv")
        self.assertEqual(len(table), 60)
        self.assertEqual(len({r["query_id"] for r in table}), 12)
        for query in {r["query_id"] for r in table}:
            subset = [r for r in table if r["query_id"] == query]
            self.assertEqual({r["method"] for r in subset},
                             {"crescent", "full_qr_gate", "classical_same_info", "no_operator", "no_gate"})
        self.assertEqual(sum(r["role"] == "prospective" for r in table), 40)
        for row in table:
            maximum = max(float(row[k]) for k in ("fluid_relative_l2", "solid_relative_l2", "joint_relative_l2"))
            self.assertEqual(maximum, float(row["max_field_relative_l2"]))

    def test_bank_and_stored_states(self):
        with np.load(DATA / "thermal_bank.npz", allow_pickle=False) as bank:
            for name in ["crescent", "classical_same_info", "no_operator", "no_gate"]:
                basis = bank[name]
                self.assertEqual(basis.shape, (480, 69))
                np.testing.assert_allclose(basis.T @ basis, np.eye(69), atol=1e-10)
                with np.load(DATA / f"thermal_query_5_{name}.npz", allow_pickle=False) as state:
                    c = state["returned"]
                    self.assertLess(np.linalg.norm(c-basis @ (basis.T @ c))/np.linalg.norm(c), 1e-10)
        with np.load(DATA / "thermal_query_5_full_qr_gate.npz", allow_pickle=False) as state:
            self.assertEqual(state["returned"].shape, (480,))

    def test_spectrum_cutoff_and_rank(self):
        spectrum = rows("thermal_bank_spectrum.csv")
        self.assertEqual(len(spectrum), 70)
        self.assertEqual(sum(r["retained"] == "True" for r in spectrum), 69)
        s = np.array([float(r["singular_value"]) for r in spectrum])
        self.assertEqual(np.count_nonzero(s > s[0]*1e-12), 69)

    def test_workload_units_and_paired_statistics(self):
        report = summarize()
        self.assertEqual(report["thermal_workload"]["method_query_realization_records"], 7500)
        self.assertEqual(report["thermal_workload"]["sampling_realizations"], 5)
        self.assertAlmostEqual(report["thermal_workload"]["mean_paired_complete_process_speedup"], 4.767189948, places=8)
        self.assertAlmostEqual(report["thermal_workload"]["sample_sd_paired_speedup"], .975674544, places=8)
        self.assertEqual(report["thermal_transfer"]["all_methods_field_target_pass_counts"]["no_operator"], 6)
        self.assertEqual(report["thermal_transfer"]["all_methods_field_target_pass_counts"]["crescent"], 12)
        self.assertEqual(report["thermal_transfer"]["prospective_conditions"], 8)

    def test_cost_semantics_preserved(self):
        for row in rows("thermal_transfer_costs.csv"):
            self.assertAlmostEqual(float(row["offline_s"])+float(row["query_s"]), float(row["total_s"]), places=12)
        for row in rows("thermal_contact.csv"):
            total = float(row["algorithm_service_s"])+float(row["historical_source_solution_once_s"])
            self.assertAlmostEqual(total, float(row["history_inclusive_service_s"]), places=11)
        self.assertEqual(len(rows("mhd_continuation.csv")), 27)
        for row in rows("transient_thermal.csv"):
            self.assertGreaterEqual(float(row["cold_s"]), float(row["online_s"]))

    def test_pairing_rejects_duplicate_records(self):
        values = [{"unit": "a", "method": "x", "value": "1."}]*2
        with self.assertRaises(ValueError):
            paired(values, "unit", "method", "value", "x", "y")


if __name__ == "__main__":
    unittest.main()
