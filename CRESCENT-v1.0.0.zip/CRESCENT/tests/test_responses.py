import unittest

import numpy as np

from crescent import SourceFactor, equilibrated_lstsq, response_basis


class ResponseTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(42)
        self.a = rng.normal(size=(16, 7))
        self.ak = .1 * rng.normal(size=self.a.shape)
        self.av = .1 * rng.normal(size=self.a.shape)
        self.b, self.bx, self.bxx = rng.normal(size=(3, 16))
        self.factor = SourceFactor(self.a)

    def direct(self, k=0., s=0., x=0.):
        return np.linalg.lstsq(
            self.a + k * self.ak + s * self.av,
            self.b + x * self.bx + .5 * x*x * self.bxx, rcond=None,
        )[0]

    def test_source_solve_matches_independent_lstsq(self):
        np.testing.assert_allclose(self.factor.solve(self.b), self.direct(), atol=2e-14)

    def test_equilibrated_solve(self):
        c, rank, singular = equilibrated_lstsq(self.a, self.b)
        self.assertEqual(rank, 7)
        self.assertEqual(singular.shape, (7,))
        np.testing.assert_allclose(c, self.direct(), atol=2e-14)

    def test_first_response_keeps_adjoint_residual(self):
        h = 1e-5
        got = self.factor.first_response(self.b, self.ak, np.zeros(16))
        expected = (self.direct(k=h) - self.direct(k=-h)) / (2*h)
        np.testing.assert_allclose(got, expected, atol=1e-9, rtol=1e-7)
        c = self.factor.solve(self.b)
        without_adjoint = np.linalg.solve(self.a.T @ self.a, -self.a.T @ self.ak @ c)
        self.assertGreater(np.linalg.norm(got - without_adjoint), 1e-3)

    def test_ten_columns_against_finite_differences(self):
        c = self.factor.thermal_columns(self.b, self.ak, self.av, self.bx, self.bxx)
        self.assertEqual(c.shape, (7, 10))
        h = 2e-4
        origin = self.direct()
        kk = (self.direct(k=h) - 2*origin + self.direct(k=-h)) / h**2
        ss = (self.direct(s=h) - 2*origin + self.direct(s=-h)) / h**2

        def mixed(left, right):
            def value(a, b):
                return self.direct(**{left: a*h, right: b*h})
            return (value(1, 1) - value(1, -1) - value(-1, 1) + value(-1, -1)) / (4*h*h)

        expected = [origin,
                    (self.direct(k=h)-self.direct(k=-h))/(2*h),
                    (self.direct(x=h)-self.direct(x=-h))/(2*h),
                    kk, mixed("k", "x"), self.factor.solve(self.bxx),
                    (self.direct(s=h)-self.direct(s=-h))/(2*h),
                    ss, mixed("k", "s"), mixed("x", "s")]
        for index, expected_column in enumerate(expected):
            with self.subTest(column=index):
                np.testing.assert_allclose(c[:, index], expected_column, atol=1e-7, rtol=3e-5)

    def test_factor_owns_source_matrix(self):
        matrix = self.a.copy()
        factor = SourceFactor(matrix)
        matrix[:] = 0.
        np.testing.assert_allclose(factor.solve(self.b), self.direct(), atol=2e-14)

    def test_bank_normalization_and_rank(self):
        columns = np.array([[1., 1e8, 0.], [0., 0., 1e-8], [0., 0., 0.]])
        basis, spectrum = response_basis(columns)
        self.assertEqual(basis.shape, (3, 2))
        self.assertEqual(len(spectrum), 3)
        np.testing.assert_allclose(basis.T @ basis, np.eye(2), atol=1e-14)
        np.testing.assert_allclose(basis @ basis.T, np.diag([1., 1., 0.]), atol=1e-14)

    def test_rank_deficient_query_lstsq_is_explicit(self):
        a = np.array([[1., 1.], [2., 2.], [3., 3.]])
        c, rank, _ = equilibrated_lstsq(a, [2., 4., 6.])
        self.assertEqual(rank, 1)
        np.testing.assert_allclose(a @ c, [2., 4., 6.], atol=1e-13)

    def test_bad_source_operators(self):
        for a in [np.zeros((3, 2)), np.ones((3, 2)), np.eye(3)[:2],
                  np.array([[np.nan], [1.]]), np.ones((2, 1), dtype=complex)]:
            with self.subTest(shape=a.shape), self.assertRaises((ValueError, np.linalg.LinAlgError)):
                SourceFactor(a)

    def test_bad_banks(self):
        for a in [np.empty((3, 0)), np.zeros((3, 2)), np.array([[np.inf]])]:
            with self.subTest(shape=a.shape), self.assertRaises(ValueError):
                response_basis(a)

    def test_bad_tolerances(self):
        for rtol in [0., -1., 1., np.nan, np.inf]:
            with self.subTest(rtol=rtol), self.assertRaises(ValueError):
                response_basis(np.eye(2), rtol)

    def test_bad_derivative_shapes(self):
        with self.assertRaises(ValueError):
            self.factor.first_response(self.b, np.eye(2), np.zeros(16))
        with self.assertRaises(ValueError):
            self.factor.thermal_columns(self.b, self.ak, self.av, np.zeros(3), self.bxx)

    def test_nonfinite_rhs(self):
        rhs = self.b.copy()
        rhs[0] = np.inf
        with self.assertRaises(ValueError):
            self.factor.solve(rhs)

    def test_zero_query_column(self):
        with self.assertRaises(ValueError):
            equilibrated_lstsq(np.zeros((2, 1)), [1., 2.])


if __name__ == "__main__":
    unittest.main()
