import unittest

import numpy as np

from crescent import admissible_state, promote_accepted, solve_query


class ReuseTests(unittest.TestCase):
    def test_affine_constraint_identity(self):
        c = np.array([[1., 0., 0., 0.], [0., 0., 0., 1.]])
        z = np.eye(4)[:, 1:3]
        q = admissible_state([3., 0., 0., 5.], z, [.2, .3], c, [3., 5.])
        np.testing.assert_array_equal(c @ q, [3., 5.])

    def test_invalid_lift_rejected(self):
        with self.assertRaises(ValueError):
            admissible_state([0., 0.], [[0.], [1.]], [2.], [[1., 0.]], [1.])

    def test_invalid_null_map_rejected(self):
        with self.assertRaises(ValueError):
            admissible_state([1., 0.], [[1.], [1.]], [2.], [[1., 0.]], [1.])

    def test_query_accepted(self):
        v = np.eye(3)[:, :2]
        result = solve_query(np.eye(3), [2., 3., 4.], [0., 0., 4.], v, lambda x: True)
        self.assertTrue(result.accepted)
        self.assertEqual(result.solve_rank, 2)
        np.testing.assert_allclose(result.state, [2., 3., 4.], atol=1e-14)

    def test_rejection_is_exact_and_does_not_mutate_anchor(self):
        anchor = np.array([np.nextafter(.1, 1), -.0, 3.])
        before = anchor.tobytes()
        result = solve_query(np.eye(3), [2., 3., 4.], anchor, np.eye(3), lambda x: False)
        self.assertEqual(result.state.tobytes(), before)
        self.assertEqual(anchor.tobytes(), before)
        self.assertFalse(np.array_equal(result.candidate, anchor))

    def test_gate_receives_readonly_copy(self):
        def gate(state):
            self.assertFalse(state.flags.writeable)
            return True
        solve_query(np.eye(2), [1., 2.], [0., 0.], np.eye(2), gate)

    def test_non_boolean_gate_rejected(self):
        for answer in [np.nan, 1, [True], None]:
            with self.subTest(answer=answer), self.assertRaises(ValueError):
                solve_query(np.eye(2), [1., 2.], [0., 0.], np.eye(2), lambda x: answer)

    def test_non_orthogonal_query_basis(self):
        with self.assertRaises(ValueError):
            solve_query(np.eye(2), [1., 2.], [0., 0.], np.ones((2, 2)), lambda x: True)

    def test_promotion_preserves_old_columns_and_rank_cap(self):
        basis = np.eye(6)[:, [0, 2, 4]]
        extended, count = promote_accepted(
            basis, [0., 1., 0., 2., 0., 3.], [2, 2, 2],
            solve_pass=True, validation_pass=True, max_rank=5,
        )
        self.assertEqual(count, 2)
        np.testing.assert_array_equal(extended[:, :3], basis)
        np.testing.assert_allclose(extended.T @ extended, np.eye(5), atol=1e-13)

    def test_zero_or_contained_increment_adds_nothing(self):
        basis = np.eye(4)[:, :2]
        for increment in [np.zeros(4), np.array([1., 2., 0., 0.])]:
            out, added = promote_accepted(
                basis, increment, [2, 2], solve_pass=True, validation_pass=True, max_rank=4,
            )
            self.assertEqual(added, 0)
            np.testing.assert_array_equal(out, basis)

    def test_promotion_requires_two_boolean_passes(self):
        for solve, validation in [(False, True), (True, False), (1, True), (True, np.nan)]:
            with self.subTest(solve=solve, validation=validation), self.assertRaises(ValueError):
                promote_accepted(np.eye(2)[:, :1], [1., 1.], [1, 1],
                                 solve_pass=solve, validation_pass=validation, max_rank=2)

    def test_promotion_empty_start(self):
        out, added = promote_accepted(
            np.empty((3, 0)), [1., 2., 3.], [1, 1, 1],
            solve_pass=True, validation_pass=True, max_rank=3,
        )
        self.assertEqual(added, 3)
        np.testing.assert_allclose(out.T @ out, np.eye(3), atol=1e-14)

    def test_rank_cap_is_noop(self):
        basis = np.eye(3)[:, :1]
        out, added = promote_accepted(basis, [0., 1., 2.], [1, 2],
                                     solve_pass=True, validation_pass=True, max_rank=1)
        self.assertEqual(added, 0)
        np.testing.assert_array_equal(out, basis)

    def test_bad_partition_or_cap(self):
        for sizes, cap in [([1, 1], 3), ([0, 3], 3), ([3], 4), ([1.5, 1.5], 3)]:
            with self.subTest(sizes=sizes, cap=cap), self.assertRaises(ValueError):
                promote_accepted(np.eye(3)[:, :1], [1., 2., 3.], sizes,
                                 solve_pass=True, validation_pass=True, max_rank=cap)


if __name__ == "__main__":
    unittest.main()
