import unittest

import numpy as np

from crescent import ThermalROM


class ThermalTests(unittest.TestCase):
    def setUp(self):
        self.mass = np.array([2., 3., 4.])
        self.a = np.array([[2., -1., 0.], [-1., 3., -1.], [0., -1., 2.]])
        self.ports = np.array([[2., 0.], [0., 1.], [1., 1.]])
        self.initial = np.array([20., 21., 22.])
        self.dt = .05

    def make(self, **changes):
        kwargs = dict(mass=self.mass, stiffness=self.a, ports=self.ports,
                      initial=self.initial, dt=self.dt, basis=np.eye(3))
        kwargs.update(changes)
        return ThermalROM(**kwargs)

    def test_full_space_agrees_with_direct_recurrence(self):
        inputs = np.random.default_rng(31).normal(size=(12, 2))
        got = self.make().solve(inputs)
        direct = np.empty_like(got)
        direct[0] = self.initial
        matrix = np.diag(self.mass / self.dt) + self.a
        for j in range(1, len(inputs)):
            direct[j] = np.linalg.solve(
                matrix, self.mass / self.dt * direct[j-1] + self.ports @ inputs[j]
            )
        np.testing.assert_allclose(got, direct, atol=2e-12, rtol=2e-13)

    def test_galerkin_residual_orthogonality(self):
        q, _ = np.linalg.qr(np.array([[1., 0.], [1., 1.], [0., 1.]]))
        inputs = np.ones((5, 2))
        got = self.make(basis=q).solve(inputs)
        for j in range(1, len(inputs)):
            residual = self.mass * (got[j]-got[j-1]) / self.dt + self.a @ got[j] - self.ports @ inputs[j]
            np.testing.assert_allclose(q.T @ (residual / np.sqrt(self.mass)), 0., atol=3e-12)

    def test_initial_lift_exact(self):
        got = self.make(basis=np.ones((3, 1))).solve(np.ones((1, 2)))
        np.testing.assert_array_equal(got[0], self.initial)

    def test_global_qr_accepts_independent_nonorthogonal_columns(self):
        raw = np.array([[1., 1., 1.], [0., 1., 1.], [0., 0., 1.]])
        inputs = np.ones((4, 2))
        np.testing.assert_allclose(self.make(basis=raw).solve(inputs), self.make().solve(inputs), atol=1e-12)

    def test_reused_operator_does_not_cache_target_history(self):
        model = self.make()
        a = model.solve(np.ones((5, 2)))
        b = model.solve(np.zeros((5, 2)))
        self.assertGreater(np.max(abs(a-b)), .01)
        np.testing.assert_array_equal(a, model.solve(np.ones((5, 2))))

    def test_constant_equilibrium(self):
        mass = np.array([2., 3.])
        a = np.array([[1., -1.], [-1., 1.]])
        got = ThermalROM(mass, a, np.ones((2, 1)), [25., 25.], .1, np.eye(2)).solve(np.zeros((4, 1)))
        np.testing.assert_array_equal(got, np.full((4, 2), 25.))

    def test_scalar_units(self):
        got = ThermalROM([2.], [[3.]], [[9.]], [1.], .25, [[1.]]).solve(np.ones((2, 1)))
        self.assertAlmostEqual(got[1, 0], (2/.25 + 9)/(2/.25 + 3), places=14)

    def test_invalid_thermal_inputs(self):
        cases = [
            dict(mass=[0., 3., 4.]), dict(dt=0.), dict(dt=np.nan),
            dict(stiffness=-np.eye(3)),
            dict(stiffness=np.array([[2., 1., 0.], [0., 2., 0.], [0., 0., 2.]])),
            dict(basis=np.ones((3, 2))), dict(basis=np.ones((2, 1))),
            dict(ports=np.ones((2, 1))), dict(initial=[20., np.inf, 20.]),
        ]
        for case in cases:
            with self.subTest(case=case), self.assertRaises(ValueError):
                self.make(**case)

    def test_bad_time_series(self):
        model = self.make()
        for values in [np.empty((0, 2)), np.ones((3, 1)), np.full((3, 2), np.nan)]:
            with self.subTest(shape=values.shape), self.assertRaises(ValueError):
                model.solve(values)


if __name__ == "__main__":
    unittest.main()
