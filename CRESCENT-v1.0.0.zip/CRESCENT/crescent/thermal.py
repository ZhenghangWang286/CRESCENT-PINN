"""Dense reduced implicit-Euler kernel for a fixed conservative thermal model.

The inputs are assembled thermal operators, an initial temperature field,
a time step, and a response basis in mass-scaled coordinates.
"""

import numpy as np
from scipy import linalg

from ._validation import array, tolerance, vector


class ThermalROM:
    """Global-QR, mass-scaled reduced symmetric thermal recurrence.

    mass is positive cell heat capacity [J/K], stiffness is symmetric positive
    semidefinite [W/K], ports @ inputs is cell power [W], initial is [K], and
    dt is [s]. basis spans mass-scaled temperature increments. The object
    caches reduced operators for reuse across supplied forcing histories.
    """

    def __init__(self, mass, stiffness, ports, initial, dt, basis, rank_rtol=1e-11):
        m = array(mass, "mass", 1)
        n = len(m)
        if n == 0 or np.any(m <= 0):
            raise ValueError("mass must be nonempty and strictly positive")
        if not np.isfinite(dt) or dt <= 0:
            raise ValueError("dt must be finite and positive")
        tolerance(rank_rtol, "rank_rtol")
        a = array(stiffness, "stiffness", 2)
        b = array(ports, "ports", 2)
        t0 = vector(initial, "initial", n)
        raw = array(basis, "basis", 2)
        if a.shape != (n, n) or b.shape[0] != n or b.shape[1] == 0:
            raise ValueError("thermal operator dimensions differ")
        if raw.shape[0] != n or not 0 < raw.shape[1] <= n:
            raise ValueError("basis dimensions differ")
        scale = max(linalg.norm(a, ord=np.inf), np.finfo(float).tiny)
        if linalg.norm(a - a.T, ord=np.inf) > 1e-12 * scale:
            raise ValueError("stiffness must be symmetric")
        if linalg.eigvalsh(a)[0] < -1e-12 * scale:
            raise ValueError("stiffness must be positive semidefinite")
        singular = linalg.svdvals(raw)
        if np.count_nonzero(singular > rank_rtol * singular[0]) != raw.shape[1]:
            raise ValueError("basis columns must be independent")
        root = np.sqrt(m)
        system = np.eye(n) + dt * a / root[:, None] / root[None, :]
        forcing = dt * np.column_stack((b, -a @ t0)) / root[:, None]
        q, _ = linalg.qr(raw, mode="economic")
        eigenvalues, rotation = linalg.eigh(q.T @ system @ q)
        if np.any(eigenvalues <= 0):
            raise np.linalg.LinAlgError("reduced system is not positive definite")
        self._basis = q @ rotation
        self._eigenvalues = eigenvalues
        self._port_map = self._basis.T @ forcing
        self._root = root
        self._initial = t0
        self._ports = b.shape[1]

    def solve(self, inputs):
        """Reconstruct all temperatures for inputs shaped (time, ports).

        inputs[0] is the initial-time sample. The returned first row equals
        initial exactly; forcing at row j acts on the step ending at j.
        """
        values = array(inputs, "inputs", 2)
        if values.shape[1] != self._ports or values.shape[0] == 0:
            raise ValueError("inputs must have shape (positive_time_count, ports)")
        forcing = np.column_stack((values, np.ones(len(values)))) @ self._port_map.T
        z = np.zeros((len(values), len(self._eigenvalues)))
        for j in range(1, len(values)):
            z[j] = (z[j - 1] + forcing[j]) / self._eigenvalues
        temperatures = self._initial + (z @ self._basis.T) / self._root
        if not np.isfinite(temperatures).all():
            raise FloatingPointError("thermal recurrence produced nonfinite values")
        return temperatures
