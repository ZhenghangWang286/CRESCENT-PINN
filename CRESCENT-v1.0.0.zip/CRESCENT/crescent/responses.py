"""Source sensitivities and a column-normalized response basis.

The source operator is tall and full column rank. Derivatives are taken in
its native coefficient coordinates, including the adjoint-residual term of
an inconsistent least-squares problem.
"""

import numpy as np
from scipy import linalg

from ._validation import array, tolerance, vector


def equilibrated_lstsq(operator, rhs, rtol=1e-12):
    """Solve a column-equilibrated system with SVD truncation.

    Returns coefficients, numerical rank, and singular values of the scaled
    operator. Rank-deficient systems are supported; columns must have
    positive norms.
    """
    a = array(operator, "operator", 2)
    b = vector(rhs, "rhs", a.shape[0])
    tolerance(rtol)
    if min(a.shape) == 0:
        raise ValueError("operator must be nonempty")
    norms = linalg.norm(a, axis=0)
    if np.any(norms == 0):
        raise ValueError("operator contains a zero column")
    z, _, rank, spectrum = linalg.lstsq(
        a / norms, b, cond=rtol, lapack_driver="gelsd"
    )
    return z / norms, int(rank), spectrum


def response_basis(columns, rtol=1e-12):
    """Normalize source columns and retain singular values above rtol*s[0].

    Returns an orthonormal basis and the complete scaled-bank spectrum.
    The column order and sign of an SVD basis are not physical observables.
    """
    raw = array(columns, "columns", 2)
    tolerance(rtol)
    if min(raw.shape) == 0:
        raise ValueError("columns must be nonempty")
    norms = linalg.norm(raw, axis=0)
    if np.any(norms == 0):
        raise ValueError("source response contains a zero column")
    u, spectrum, _ = linalg.svd(raw / norms, full_matrices=False)
    rank = int(np.count_nonzero(spectrum > rtol * spectrum[0]))
    return u[:, :rank], spectrum


class SourceFactor:
    """A source operator's equilibrated QR factorization, owned by value.

    Subsequent mutations of the caller's matrix do not alter this factor.
    Construct a new factor when the physical source operator changes.
    """

    def __init__(self, operator, rtol=1e-12):
        a = array(operator, "operator", 2)
        tolerance(rtol)
        if not 0 < a.shape[1] <= a.shape[0]:
            raise ValueError("a nonempty tall operator is required")
        norms = linalg.norm(a, axis=0)
        if np.any(norms == 0):
            raise np.linalg.LinAlgError("source operator contains a zero column")
        scale = 1.0 / norms
        spectrum = linalg.svdvals(a * scale)
        if np.count_nonzero(spectrum > rtol * spectrum[0]) != a.shape[1]:
            raise np.linalg.LinAlgError("source operator must have full column rank")
        self._a = a
        self._scale = scale
        self._q, self._r = linalg.qr(a * scale, mode="economic")

    def solve(self, rhs):
        """Solve one source right-hand side using the cached QR factors."""
        b = vector(rhs, "rhs", self._a.shape[0])
        z = linalg.solve_triangular(self._r, self._q.T @ b)
        return self._scale * z

    def _normal_solve(self, rhs):
        # Apply (A.T A)^-1 without constructing the normal-equation matrix.
        z = linalg.solve_triangular(self._r.T, self._scale * rhs, lower=True)
        return self._scale * linalg.solve_triangular(self._r, z)

    def first_response(self, rhs, operator_derivative, rhs_derivative):
        """Differentiate A.T @ (A @ c - b) = 0 at the factored source."""
        a = self._a
        b = vector(rhs, "rhs", a.shape[0])
        da = array(operator_derivative, "operator_derivative", 2)
        db = vector(rhs_derivative, "rhs_derivative", a.shape[0])
        if da.shape != a.shape:
            raise ValueError("operator derivative shape mismatch")
        c = self.solve(b)
        residual = a @ c - b
        return self._normal_solve(a.T @ (db - da @ c) - da.T @ residual)

    def thermal_columns(self, rhs, a_kappa, a_velocity, rhs_x, rhs_xx):
        """Return the ten response columns used by the thermal source bank.

        A(kappa, s) is affine and b(x) depends on source position.
        Order: c, c_k, c_x, c_kk, c_kx, c_xx, c_s, c_ss, c_ks, c_xs.
        A single factor can serve several source positions.
        """
        a = self._a
        b = vector(rhs, "rhs", a.shape[0])
        bx = vector(rhs_x, "rhs_x", a.shape[0])
        bxx = vector(rhs_xx, "rhs_xx", a.shape[0])
        ak = array(a_kappa, "a_kappa", 2)
        av = array(a_velocity, "a_velocity", 2)
        if ak.shape != a.shape or av.shape != a.shape:
            raise ValueError("operator derivative shape mismatch")
        c = self.solve(b)
        ck = self.first_response(b, ak, np.zeros_like(b))
        cx = self.solve(bx)
        cv = self.first_response(b, av, np.zeros_like(b))

        def hp(da, v):
            return da.T @ (a @ v) + a.T @ (da @ v)

        ckk = self._normal_solve(-2 * hp(ak, ck) - 2 * ak.T @ (ak @ c))
        ckx = self._normal_solve(ak.T @ bx - hp(ak, cx))
        cxx = self.solve(bxx)
        rv = av @ c + a @ cv
        rk = ak @ c + a @ ck
        cvv = self._normal_solve(-2 * av.T @ rv - 2 * a.T @ (av @ cv))
        ckv = self._normal_solve(-ak.T @ rv - av.T @ rk - a.T @ (ak @ cv + av @ ck))
        cvx = self._normal_solve(av.T @ bx - hp(av, cx))
        return np.column_stack((c, ck, cx, ckk, ckx, cxx, cv, cvv, ckv, cvx))
