"""Admissible reconstruction, checked queries and accepted-state promotion."""

from dataclasses import dataclass

import numpy as np
from scipy import linalg

from ._validation import array, orthonormal, tolerance, vector
from .responses import equilibrated_lstsq


@dataclass(frozen=True)
class QueryResult:
    state: np.ndarray
    candidate: np.ndarray
    accepted: bool
    solve_rank: int


def admissible_state(lift, null_map, coefficients, constraint, prescribed, atol=1e-12):
    """Evaluate q = lift + Z*c after checking C*lift=d and C*Z=0.

    Validate the supplied lift and null map using an absolute tolerance
    expressed in the caller's constraint units.
    """
    z = array(null_map, "null_map", 2)
    c = vector(coefficients, "coefficients", z.shape[1])
    ql = vector(lift, "lift", z.shape[0])
    operator = array(constraint, "constraint", 2)
    if operator.shape[1] != len(ql):
        raise ValueError("constraint shape mismatch")
    d = vector(prescribed, "prescribed", operator.shape[0])
    if not np.isfinite(atol) or atol <= 0:
        raise ValueError("atol must be finite and positive")
    if not np.allclose(operator @ ql, d, rtol=0, atol=atol):
        raise ValueError("lift violates the prescribed constraint")
    if not np.allclose(operator @ z, 0, rtol=0, atol=atol):
        raise ValueError("null_map changes an immutable constraint")
    q = ql + z @ c
    if not np.allclose(operator @ q, d, rtol=0, atol=atol):
        raise ValueError("reconstructed constraint exceeds tolerance")
    return q


def solve_query(operator, rhs, anchor, basis, held_gate, rtol=1e-12):
    """Solve in a frozen response space and accept or revert exactly.

    held_gate receives a read-only copy of the candidate free coefficients
    and returns a boolean from independent physics checks. Acceptance returns
    the candidate; rejection returns the original anchor exactly.
    """
    a = array(operator, "operator", 2)
    b = vector(rhs, "rhs", a.shape[0])
    c0 = vector(anchor, "anchor", a.shape[1])
    v = orthonormal(basis)
    if v.shape[0] != len(c0):
        raise ValueError("basis and operator dimensions differ")
    if not callable(held_gate):
        raise ValueError("held_gate must be callable")
    beta, rank, _ = equilibrated_lstsq(a @ v, b - a @ c0, rtol)
    candidate = c0 + v @ beta
    if not np.isfinite(candidate).all():
        raise FloatingPointError("query produced a nonfinite candidate")
    check_state = candidate.copy()
    check_state.setflags(write=False)
    accepted = held_gate(check_state)
    if not isinstance(accepted, (bool, np.bool_)):
        raise ValueError("held_gate must return a boolean")
    returned = candidate if accepted else c0
    return QueryResult(returned.copy(), candidate.copy(), bool(accepted), rank)


def promote_accepted(basis, increment, block_sizes, *, solve_pass, validation_pass,
                     max_rank, max_new=3, promotion_rtol=1e-8,
                     promotion_atol=1e-14, rank_rtol=1e-10):
    """Append field-split directions from a solved and validated correction.

    Old columns are not rotated. Twice-projected block increments are
    filtered, orthogonalized by SVD, then reprojected and QR-normalized.
    Returns (new_basis, number_added). Cached projected maps must be rebuilt
    or extended by the caller after a nonzero addition.
    """
    if not isinstance(solve_pass, (bool, np.bool_)) or not isinstance(validation_pass, (bool, np.bool_)):
        raise ValueError("acceptance flags must be boolean")
    if not (solve_pass and validation_pass):
        raise ValueError("bank updates require solved and validated states")
    v = orthonormal(basis, allow_empty=True)
    delta = vector(increment, "increment", v.shape[0])
    sizes = tuple(block_sizes)
    if not sizes or any(isinstance(x, bool) or not isinstance(x, (int, np.integer)) or x <= 0 for x in sizes):
        raise ValueError("block_sizes must be positive integers")
    if sum(sizes) != v.shape[0]:
        raise ValueError("block_sizes must partition the coefficient vector")
    for value, name in [(max_rank, "max_rank"), (max_new, "max_new")]:
        if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value < 0:
            raise ValueError(f"{name} must be a nonnegative integer")
    if not v.shape[1] <= max_rank <= v.shape[0]:
        raise ValueError("max_rank must lie between current rank and dimension")
    tolerance(promotion_rtol, "promotion_rtol")
    tolerance(rank_rtol, "rank_rtol")
    if not np.isfinite(promotion_atol) or promotion_atol <= 0:
        raise ValueError("promotion_atol must be finite and positive")
    cap = min(max_new, max_rank - v.shape[1])
    if cap == 0:
        return v, 0
    candidates = []
    start = 0
    for size in sizes:
        part = np.zeros_like(delta)
        part[start:start + size] = delta[start:start + size]
        start += size
        norm = linalg.norm(part)
        residual = part.copy()
        for _ in range(2):
            residual -= v @ (v.T @ residual)
        orth_norm = linalg.norm(residual)
        if norm > promotion_atol and orth_norm > promotion_atol and orth_norm / norm > promotion_rtol:
            candidates.append(residual / orth_norm)
    if not candidates:
        return v, 0
    q, spectrum, _ = linalg.svd(np.column_stack(candidates), full_matrices=False)
    rank = int(np.count_nonzero(spectrum > rank_rtol * spectrum[0]))
    add = q[:, :min(cap, rank)].copy()
    for _ in range(2):
        add -= v @ (v.T @ add)
    add, _ = linalg.qr(add, mode="economic")
    return np.column_stack((v, add)), add.shape[1]
