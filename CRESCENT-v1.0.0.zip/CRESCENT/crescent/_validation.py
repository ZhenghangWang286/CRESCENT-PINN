"""Shape and finite-value checks shared by the numerical kernels."""

import numpy as np


def array(value, name, ndim):
    raw = np.asarray(value)
    if np.iscomplexobj(raw):
        raise ValueError(f"{name} must be real")
    out = np.array(raw, dtype=np.float64, copy=True)
    if out.ndim != ndim or not np.isfinite(out).all():
        raise ValueError(f"{name} must be a finite {ndim}-dimensional array")
    return out


def vector(value, name, size):
    out = array(value, name, 1)
    if out.shape != (size,):
        raise ValueError(f"{name} must have shape ({size},)")
    return out


def tolerance(value, name="rtol"):
    if not np.isscalar(value) or not np.isfinite(value) or not 0 < value < 1:
        raise ValueError(f"{name} must lie strictly between zero and one")
    return float(value)


def orthonormal(value, name="basis", allow_empty=False):
    out = array(value, name, 2)
    n, k = out.shape
    if n == 0 or k > n or (k == 0 and not allow_empty):
        raise ValueError(f"{name} has invalid dimensions")
    if not np.allclose(out.T @ out, np.eye(k), rtol=0, atol=1e-9):
        raise ValueError(f"{name} must have orthonormal columns")
    return out
