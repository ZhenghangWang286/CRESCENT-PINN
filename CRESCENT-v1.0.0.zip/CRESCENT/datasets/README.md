# Research data

These datasets accompany *A transferable memory of physical responses for
scientific computing*. CSV values retain their recorded precision. NumPy
archives contain the thermal response bases and query coefficient arrays.
The analysis commands read these files to reconstruct stored coefficients
and calculate statistics from the recorded measurements.

## Dataset map

| File | Contents and observation unit |
|---|---|
| `thermal_bank_spectrum.csv` | 70 scaled-bank singular values; 69 retained at relative cutoff 1e-12 |
| `thermal_transfer.csv` | 12 conditions x 5 methods; fieldwise relative L2 differences and acceptance flags |
| `thermal_transfer_costs.csv` | Five methods; source/setup and query costs in seconds |
| `thermal_workload.csv` | 5 sampling realizations x 3 methods; each row summarizes the same 500-condition workload |
| `thermal_contact.csv` | 3 technical timing repetitions x 3 methods; 16 physical queries per repetition |
| `mhd_timing.csv` | 5 technical timing repetitions x 3 methods; four physical queries per repetition |
| `mhd_continuation.csv` | Three methods at nine cumulative checkpoints, queries 4 through 12 |
| `transient_thermal.csv` | Two reduced branches for five model configurations, including three 3D cases |
| `thermal_bank.npz` | Four stored bases, each shaped (480, 69) |
| `thermal_query_5_*.npz` | First prospective condition; candidate and returned coefficients for five methods |

In `thermal_transfer.csv`, the `role` column distinguishes four development
retest conditions from eight prospective conditions. Each condition has one
record per method.

The manifest lists each file's SHA-256 checksum and CSV fields. Load the
NumPy archives with `allow_pickle=False`.

## Coefficient coordinates

Thermal coefficients are ordered as 225 fluid-interior, 225 solid-interior,
15 shared-temperature and 15 shared-physical-flux coefficients. The bank
arrays contain basis columns in this coefficient coordinate system. Query 5
has zero-based source index 4; its physical parameters are given in
`thermal_transfer.csv`.

## Method labels

| Label | Method |
|---|---|
| `crescent` | SVD response bank with enforced physics checks |
| `classical_same_info` | Pivoted-QR basis built from the same response information |
| `no_operator` | Source snapshots plus deterministic low-order coordinates, at matched dimension |
| `no_gate` | Response basis with diagnostic physics checks |
| `full_qr_gate` | Full admissible-space transfer solve using equilibrated SVD least squares |
| `projected_guarded` / `classical_rom_qr` / `fast_qr` | Checked response-space / matched classical reduced / full-space methods in the 500-query workload |
| `field_nested` / `classical_nested` / `full_affine_qr` | Response / matched classical / full-space methods in the contact workload |
| `margin_selective69` / `margin_uniform69` / `margin_classical_qr69` | Selective / uniform / matched classical coupled-field corrections |
| `fixed69` / `online_field_qr` / `online_field_svd` | Fixed 69-direction / QR-enriched / SVD-enriched methods in the continuation table |

## Error and acceptance metrics

Thermal-transfer differences are Euclidean relative L2 norms evaluated
separately for fluid, solid and their concatenation against the independently
refined numerical reference. `max_field_relative_l2` is the maximum of these
three norms. `field_target_pass` applies a threshold of 1e-3. Physics
acceptance and the field-difference target are evaluated separately and
recorded in their respective columns.

For transient thermal data, `same_grid_relative_l2` compares with a direct
solution on the same model grid. `same_grid_max_abs_K` is the maximum
temperature difference in kelvin. Algebraic residual and energy imbalance
are reported as separate metrics.

## Timing and statistical definitions

The 500-query timing statistic is the mean of five paired complete-process
time ratios. Its dispersion is the sample standard deviation with `ddof=1`.
The 15 workload rows aggregate 7,500 method-query-realization evaluations.

Contact `history_inclusive_service_s` is the sum of `algorithm_service_s` and
`historical_source_solution_once_s`, charging source-solution acquisition
once. MHD `external_process_s` measures the current process; inherited lower
and upper costs are separate accounting quantities. Continuation costs
measure cumulative service beginning after source acquisition.

Transient `online_s` measures prepared-query service. `cold_s` includes
setup. The result summaries use each dataset's stated timing boundary and
observation unit.
