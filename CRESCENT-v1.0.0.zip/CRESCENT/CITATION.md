# Citation

Associated manuscript:

*A transferable memory of physical responses for scientific computing*.

Software: **CRESCENT: reusable field corrections**, version **1.0.0**.

When using this software or its datasets, cite the associated manuscript
and identify the software version.
