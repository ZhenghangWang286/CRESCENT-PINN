"""CRESCENT-PINN three-square-cylinder benchmark at Re = 100."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent

CONTROL = "#A9B1BA"
CRESCENT = "#1769AA"
GREEN = "#198754"


def load_values():
    data = json.loads((HERE / "metrics.json").read_text(encoding="utf-8"))
    methods = data["methods"]
    values = []
    for method in methods.values():
        values.extend(method["physics"].values())
        values.extend(method["boundary"].values())
        values.extend((method["adaptation_seconds"], method["cumulative_seconds"]))
    values = np.asarray(values, dtype=float)
    if not np.all(np.isfinite(values)) or np.any(values <= 0.0):
        raise ValueError("benchmark values must be finite and positive")
    return data


def ratio_panel(axis, labels, ratios, title):
    y = np.arange(len(labels))
    bars = axis.barh(y, ratios, color=GREEN, height=0.62)
    axis.axvline(1.0, color="#6C757D", linewidth=0.8, linestyle="--")
    axis.set_xscale("log")
    axis.set_yticks(y, labels)
    axis.invert_yaxis()
    axis.set_xlabel("Control / CRESCENT-PINN")
    axis.set_title(title)
    axis.grid(axis="x", color="#E9ECEF", linewidth=0.6)
    axis.set_axisbelow(True)
    for bar, ratio in zip(bars, ratios):
        axis.text(ratio * 1.04, bar.get_y() + bar.get_height() / 2, f"{ratio:.2f}x", va="center", fontsize=6.2)


def main():
    data = load_values()
    local = data["methods"]["Control"]
    crescent = data["methods"]["CRESCENT-PINN"]
    physics_labels = list(local["physics"])
    boundary_labels = list(local["boundary"])
    physics_ratio = np.array([local["physics"][name] / crescent["physics"][name] for name in physics_labels])
    boundary_ratio = np.array([local["boundary"][name] / crescent["boundary"][name] for name in boundary_labels])

    plt.rcParams.update({"font.family": "sans-serif", "font.size": 7.0, "axes.linewidth": 0.7, "svg.fonttype": "none", "pdf.fonttype": 42})
    figure, axes = plt.subplots(1, 3, figsize=(7.09, 3.35), gridspec_kw={"width_ratios": [1.15, 1.15, 0.9]})
    figure.subplots_adjust(left=0.13, right=0.985, bottom=0.20, top=0.78, wspace=0.70)

    ratio_panel(axes[0], physics_labels, physics_ratio, "Physics improvement factors")
    ratio_panel(axes[1], boundary_labels, boundary_ratio, "Boundary improvement factors")

    groups = np.arange(2)
    width = 0.34
    local_times = [local["adaptation_seconds"], local["cumulative_seconds"]]
    crescent_times = [crescent["adaptation_seconds"], crescent["cumulative_seconds"]]
    axes[2].bar(groups - width / 2, local_times, width, label="Control", color=CONTROL)
    axes[2].bar(groups + width / 2, crescent_times, width, label="CRESCENT-PINN", color=CRESCENT)
    axes[2].set_xticks(groups, ["Adaptation", "Cumulative"])
    axes[2].set_yscale("log")
    axes[2].set_ylabel("Seconds")
    axes[2].set_title("Continuation cost")
    axes[2].legend(frameon=False, fontsize=6.2, loc="upper left")
    axes[2].grid(axis="y", color="#E9ECEF", linewidth=0.6)
    axes[2].set_axisbelow(True)

    for label, axis in zip("abc", axes):
        axis.spines[["top", "right"]].set_visible(False)
        axis.text(-0.22, 1.08, label, transform=axis.transAxes, fontweight="bold", fontsize=8)
    figure.suptitle("Three staggered square cylinders, Re = 100", y=0.95, fontsize=9.5, fontweight="bold")
    figure.text(0.5, 0.045, "All eleven physics and boundary diagnostics improve; cumulative continuation time is lower.", ha="center", fontsize=6.6, color="#495057")
    figure.savefig(HERE / "re100.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


if __name__ == "__main__":
    main()
