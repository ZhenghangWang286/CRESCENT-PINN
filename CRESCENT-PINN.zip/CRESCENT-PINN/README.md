# CRESCENT-PINN

Constraint-preserving field-block residual correction for high-Reynolds-number and coupled flow systems

Zhenghang Wang, Yongbin Ge, Baiying Dong, and Tingfu Ma.

This repository accompanies the paper and includes the core CRESCENT-PINN routines together with the benchmark scripts used to regenerate the reported figures. The benchmarks cover six flow and multiphysics systems reported in the manuscript.

## Install

```bash
pip install -r requirements.txt
```

## Run

```bash
python core/crescent_step.py
python sdtr/plot_da1e4.py
python mhd/plot_ha20.py
python cavity/plot_re7500.py
python airfoil/plot_re1000.py
python squares/plot_re100.py
python cht/plot_forced.py
```

## Citation

```text
Zhenghang Wang, Yongbin Ge, Baiying Dong, and Tingfu Ma.
CRESCENT-PINN: Constraint-preserving field-block residual correction for
high-Reynolds-number and coupled flow systems.
```
