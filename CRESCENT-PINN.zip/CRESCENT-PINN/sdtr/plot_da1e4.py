"""CRESCENT-PINN staged correction for Stokes-Darcy-transport at Da = 1e-4."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent

BLUE = "#1769AA"
GREEN = "#198754"
ORANGE = "#E76F51"
PURPLE = "#6F42C1"


def load_values():
    data = json.loads((HERE / "metrics.json").read_text(encoding="utf-8"))
    stages = data["stages"]
    errors = np.array([row["worst_scalar_relative_l2"] for row in stages], dtype=float)
    closed = np.array([row["gates_closed"] for row in stages], dtype=int)
    total = np.array([row["gates_total"] for row in stages], dtype=int)
    times = np.array([row["accounted_seconds"] for row in stages], dtype=float)
    if not np.all(np.isfinite(errors)) or not np.all(np.isfinite(times)):
        raise ValueError("non-finite benchmark value")
    if np.any(errors <= 0.0) or np.any(times < 0.0) or np.any(closed < 0) or np.any(closed > total):
        raise ValueError("benchmark value outside its valid range")
    return data


def clean_axis(axis):
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(axis="y", color="#E9ECEF", linewidth=0.6)
    axis.set_axisbelow(True)


def panel_label(axis, label):
    axis.text(-0.17, 1.08, label, transform=axis.transAxes, fontweight="bold", fontsize=8)


def main():
    data = load_values()
    stages = data["stages"]
    names = [row["name"] for row in stages]
    x = np.arange(len(names))
    errors = np.array([row["worst_scalar_relative_l2"] for row in stages])
    closed = np.array([row["gates_closed"] for row in stages])
    times = np.array([row["accounted_seconds"] for row in stages])
    final = data["full_stage"]
    residual_names = ["Stokes\nmomentum", "Darcy\nmomentum", "Transport", "Interface\nmass"]
    residual_values = [final["stokes_momentum_rms"], final["darcy_momentum_rms"], final["transport_rms"], final["interface_mass_error"]]

    plt.rcParams.update({"font.family": "sans-serif", "font.size": 7.2, "axes.linewidth": 0.7, "svg.fonttype": "none", "pdf.fonttype": 42})
    figure, axes = plt.subplots(2, 2, figsize=(7.09, 4.8))
    figure.subplots_adjust(left=0.10, right=0.985, bottom=0.17, top=0.84, wspace=0.31, hspace=0.56)
    axes = axes.ravel()

    axes[0].plot(x, errors, marker="o", color=BLUE)
    axes[0].set_yscale("log")
    axes[0].set_xticks(x, names)
    axes[0].set_ylabel("Worst scalar relative L2")
    axes[0].set_title("Accuracy progression")

    axes[1].plot(x, closed, marker="o", color=GREEN)
    axes[1].axhline(stages[-1]["gates_total"], color="#ADB5BD", linewidth=0.8, linestyle="--")
    axes[1].set_xticks(x, names)
    axes[1].set_ylim(0, 16)
    axes[1].set_yticks([0, 5, 10, 15])
    axes[1].set_ylabel("Gates closed")
    axes[1].set_title("Joint physics gate")

    axes[2].bar(np.arange(4), residual_values, color=PURPLE, width=0.64)
    axes[2].set_yscale("log")
    axes[2].set_xticks(np.arange(4), residual_names)
    axes[2].set_ylabel("Error / RMS")
    axes[2].set_title("Full-stage physics diagnostics")

    axes[3].bar(x, times, width=0.62, color=["#C8CDD3", ORANGE, ORANGE])
    axes[3].set_xticks(x, names)
    axes[3].set_ylabel("Algorithm time (s)")
    axes[3].set_title("Algorithm time")

    for label, axis in zip("abcd", axes):
        clean_axis(axis)
        panel_label(axis, label)
    figure.suptitle("Stokes-Darcy-transport, Da = 1e-4", y=0.97, fontsize=10, fontweight="bold")
    figure.text(0.5, 0.035, "Analytic exact-reference verification.", ha="center", fontsize=7, color="#495057")
    figure.savefig(HERE / "da1e4.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


if __name__ == "__main__":
    main()
