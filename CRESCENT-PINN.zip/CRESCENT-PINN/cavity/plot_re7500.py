"""CRESCENT-PINN staged correction for the lid-driven cavity at Re = 7500."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent

BLUE = "#1769AA"
GREEN = "#198754"
ORANGE = "#E76F51"


def load_values():
    data = json.loads((HERE / "metrics.json").read_text(encoding="utf-8"))
    stages = data["stages"]
    mse = np.array([row["velocity_mse"] for row in stages], dtype=float)
    relative_l2 = np.array([row["velocity_relative_l2"] for row in stages], dtype=float)
    times = np.array([row["correction_stage_seconds"] for row in stages], dtype=float)
    if not np.all(np.isfinite(mse)) or not np.all(np.isfinite(relative_l2)) or not np.all(np.isfinite(times)):
        raise ValueError("non-finite benchmark value")
    if np.any(mse <= 0.0) or np.any(relative_l2 <= 0.0) or np.any(times < 0.0):
        raise ValueError("benchmark value outside its valid range")
    return data


def clean_axis(axis):
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(axis="y", color="#E9ECEF", linewidth=0.6)
    axis.set_axisbelow(True)


def panel_label(axis, label):
    axis.text(-0.18, 1.08, label, transform=axis.transAxes, fontweight="bold", fontsize=8)


def main():
    data = load_values()
    stages = data["stages"]
    names = [row["name"] for row in stages]
    x = np.arange(len(names))
    mse = np.array([row["velocity_mse"] for row in stages])
    relative_l2 = np.array([row["velocity_relative_l2"] for row in stages])
    times = np.array([row["correction_stage_seconds"] for row in stages])

    plt.rcParams.update({"font.family": "sans-serif", "font.size": 7.2, "axes.linewidth": 0.7, "svg.fonttype": "none", "pdf.fonttype": 42})
    figure, axes = plt.subplots(1, 3, figsize=(7.09, 2.45))
    figure.subplots_adjust(left=0.09, right=0.99, bottom=0.25, top=0.75, wspace=0.40)

    axes[0].plot(x, mse, marker="o", color=BLUE)
    axes[0].set_xticks(x, names)
    axes[0].set_ylabel("Velocity MSE")
    axes[0].set_title("Velocity MSE")
    axes[0].ticklabel_format(axis="y", style="sci", scilimits=(0, 0))

    axes[1].plot(x, relative_l2, marker="o", color=GREEN)
    axes[1].set_xticks(x, names)
    axes[1].set_ylabel("Velocity relative L2")
    axes[1].set_title("Velocity relative L2")

    axes[2].bar(x, times, width=0.62, color=["#C8CDD3", ORANGE, ORANGE])
    axes[2].set_xticks(x, names)
    axes[2].set_ylabel("Correction time (s)")
    axes[2].set_title("Correction-stage time")

    for label, axis in zip("abc", axes):
        clean_axis(axis)
        panel_label(axis, label)
    figure.suptitle("Lid-driven cavity, Re = 7500", y=0.94, fontsize=9.5, fontweight="bold")
    figure.text(0.5, 0.06, "All compared correction stages start from the same inherited checkpoint.", ha="center", fontsize=6.5, color="#495057")
    figure.savefig(HERE / "re7500.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


if __name__ == "__main__":
    main()
