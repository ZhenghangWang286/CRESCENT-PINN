"""Core CRESCENT correction operators, admissibility maps, and acceptance logic."""

import numpy as np


def _as_vector(values, name):
    values = np.asarray(values, dtype=float).reshape(-1)
    if not np.all(np.isfinite(values)):
        raise ValueError(f"{name} contains non-finite values")
    return values


def _symmetric_square_root(matrix):
    matrix = np.asarray(matrix, dtype=float)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError("row_weights must be a vector or square matrix")
    symmetric = 0.5 * (matrix + matrix.T)
    eigenvalues, eigenvectors = np.linalg.eigh(symmetric)
    tolerance = np.finfo(float).eps * max(1, matrix.shape[0]) * max(1.0, np.max(np.abs(eigenvalues)))
    if np.min(eigenvalues) < -tolerance:
        raise ValueError("row_weights must be positive semidefinite")
    return (eigenvectors * np.sqrt(np.maximum(eigenvalues, 0.0))) @ eigenvectors.T


def reduced_gauss_newton_direction(
    residual,
    jacobian,
    row_weights,
    coefficient_scale,
    damping,
):
    """Solve min ||W^(1/2)(r + J da)||^2 + damping ||D da||^2."""
    residual = _as_vector(residual, "residual")
    jacobian = np.asarray(jacobian, dtype=float)
    if jacobian.ndim != 2 or jacobian.shape[0] != residual.size:
        raise ValueError("jacobian and residual dimensions do not match")
    if not np.all(np.isfinite(jacobian)):
        raise ValueError("jacobian contains non-finite values")
    if not np.isfinite(damping) or damping < 0.0:
        raise ValueError("damping must be finite and non-negative")

    weights = np.asarray(row_weights, dtype=float)
    if weights.ndim == 1:
        if weights.size != residual.size or np.any(weights < 0.0) or not np.all(np.isfinite(weights)):
            raise ValueError("row_weights has an incompatible value or shape")
        weighted_residual = np.sqrt(weights) * residual
        weighted_jacobian = np.sqrt(weights)[:, None] * jacobian
    else:
        if weights.shape != (residual.size, residual.size):
            raise ValueError("row_weights has an incompatible shape")
        weight_sqrt = _symmetric_square_root(weights)
        weighted_residual = weight_sqrt @ residual
        weighted_jacobian = weight_sqrt @ jacobian

    scale = np.asarray(coefficient_scale, dtype=float)
    if scale.ndim == 1:
        if scale.size != jacobian.shape[1] or np.any(scale < 0.0) or not np.all(np.isfinite(scale)):
            raise ValueError("coefficient_scale has an incompatible value or shape")
        scale = np.diag(scale)
    if scale.ndim != 2 or scale.shape[1] != jacobian.shape[1] or not np.all(np.isfinite(scale)):
        raise ValueError("coefficient_scale has an incompatible shape")

    system = weighted_jacobian
    target = -weighted_residual
    if damping > 0.0:
        system = np.vstack((system, np.sqrt(damping) * scale))
        target = np.concatenate((target, np.zeros(scale.shape[0])))
    return np.linalg.lstsq(system, target, rcond=None)[0]


def field_block_schur_direction(
    h_ff,
    h_fgamma,
    h_gammaf,
    h_gammagamma,
    g_f,
    g_gamma,
):
    """Solve the coupled field/interface block system by Schur reduction."""
    h_ff = np.asarray(h_ff, dtype=float)
    h_fgamma = np.asarray(h_fgamma, dtype=float)
    h_gammaf = np.asarray(h_gammaf, dtype=float)
    h_gammagamma = np.asarray(h_gammagamma, dtype=float)
    g_f = _as_vector(g_f, "g_f")
    g_gamma = _as_vector(g_gamma, "g_gamma")
    if h_ff.shape != (g_f.size, g_f.size):
        raise ValueError("h_ff has an incompatible shape")
    if h_fgamma.shape != (g_f.size, g_gamma.size):
        raise ValueError("h_fgamma has an incompatible shape")
    if h_gammaf.shape != (g_gamma.size, g_f.size):
        raise ValueError("h_gammaf has an incompatible shape")
    if h_gammagamma.shape != (g_gamma.size, g_gamma.size):
        raise ValueError("h_gammagamma has an incompatible shape")

    hff_inverse_hfgamma = np.linalg.solve(h_ff, h_fgamma)
    hff_inverse_gf = np.linalg.solve(h_ff, g_f)
    schur = h_gammagamma - h_gammaf @ hff_inverse_hfgamma
    rhs_gamma = -(g_gamma - h_gammaf @ hff_inverse_gf)
    delta_gamma = np.linalg.solve(schur, rhs_gamma)
    delta_f = -np.linalg.solve(h_ff, g_f + h_fgamma @ delta_gamma)
    return delta_f, delta_gamma


def null_space_basis(constraint_operator, relative_tolerance=None):
    """Return an orthonormal basis B for the null space of A."""
    operator = np.asarray(constraint_operator, dtype=float)
    if operator.ndim != 2 or not np.all(np.isfinite(operator)):
        raise ValueError("constraint_operator must be a finite matrix")
    _, singular_values, vh = np.linalg.svd(operator, full_matrices=True)
    if relative_tolerance is None:
        relative_tolerance = np.finfo(float).eps * max(operator.shape, default=1)
    threshold = relative_tolerance * (singular_values[0] if singular_values.size else 1.0)
    rank = int(np.sum(singular_values > threshold))
    return vh[rank:].T.copy()


def admissible_direction(constraint_operator, admissible_basis, coefficients, tolerance=1.0e-11):
    """Form delta q = Bc after verifying AB = 0."""
    operator = np.asarray(constraint_operator, dtype=float)
    basis = np.asarray(admissible_basis, dtype=float)
    coefficients = _as_vector(coefficients, "coefficients")
    if operator.ndim != 2 or basis.ndim != 2 or operator.shape[1] != basis.shape[0]:
        raise ValueError("constraint_operator and admissible_basis dimensions do not match")
    if basis.shape[1] != coefficients.size:
        raise ValueError("admissible_basis and coefficients dimensions do not match")
    defect = operator @ basis
    scale = max(1.0, np.linalg.norm(operator, ord=2) * np.linalg.norm(basis, ord=2))
    if np.linalg.norm(defect, ord=2) > tolerance * scale:
        raise ValueError("admissible_basis does not satisfy AB = 0")
    return basis @ coefficients


def first_joint_gate_step(
    state,
    constraint_operator,
    admissible_basis,
    coefficients,
    trial_scales,
    held_metrics,
    primary_metric,
    primary_margin,
    protected_limits,
):
    """Accept the first prescribed scale passing the joint gate, or revert exactly."""
    baseline = np.array(state, dtype=float, copy=True)
    direction = admissible_direction(constraint_operator, admissible_basis, coefficients)
    if baseline.shape != direction.shape:
        raise ValueError("state and admissible direction must have identical shapes")
    if not 0.0 <= primary_margin < 1.0:
        raise ValueError("primary_margin must lie in [0, 1)")
    limits = {name: float(value) for name, value in protected_limits.items()}
    if any(not np.isfinite(value) for value in limits.values()):
        raise ValueError("protected limits must be finite")

    before = {name: float(value) for name, value in held_metrics(baseline).items()}
    if primary_metric not in before or not np.isfinite(before[primary_metric]):
        raise ValueError("primary metric is missing from the incoming held metrics")
    primary_limit = (1.0 - primary_margin) * before[primary_metric]
    attempt_history = []

    for scale in trial_scales:
        scale = float(scale)
        if not np.isfinite(scale) or scale <= 0.0:
            raise ValueError("trial scales must be finite and positive")
        candidate = baseline + scale * direction
        metrics = {name: float(value) for name, value in held_metrics(candidate).items()}
        primary_pass = primary_metric in metrics and np.isfinite(metrics[primary_metric]) and metrics[primary_metric] <= primary_limit
        protected_pass = all(
            name in metrics and np.isfinite(metrics[name]) and metrics[name] <= limit
            for name, limit in limits.items()
        )
        accepted = bool(primary_pass and protected_pass)
        attempt_history.append(
            {
                "scale": scale,
                "held_metrics": metrics,
                "primary_pass": bool(primary_pass),
                "protected_pass": bool(protected_pass),
                "accepted": accepted,
            }
        )
        if accepted:
            return {
                "state": np.array(candidate, copy=True),
                "accepted": True,
                "decision": "accepted",
                "scale": scale,
                "held_before": before,
                "held_after": metrics,
                "prior_candidate_count": len(attempt_history) - 1,
                "attempt_history": attempt_history,
            }

    return {
        "state": np.array(baseline, copy=True),
        "accepted": False,
        "decision": "exact_revert",
        "scale": 0.0,
        "held_before": before,
        "held_after": dict(before),
        "prior_candidate_count": len(attempt_history),
        "attempt_history": attempt_history,
    }


def _check_core():
    residual = np.array([1.0, -0.5, 0.25])
    jacobian = np.array([[2.0, 0.0], [0.0, 1.0], [1.0, -1.0]])
    weights = np.array([2.0, 1.0, 0.5])
    scale = np.array([1.0, 3.0])
    delta = reduced_gauss_newton_direction(residual, jacobian, weights, scale, 1.0e-3)
    normal = jacobian.T @ np.diag(weights) @ jacobian + 1.0e-3 * np.diag(scale) @ np.diag(scale)
    rhs = -(jacobian.T @ np.diag(weights) @ residual)
    if not np.allclose(normal @ delta, rhs, rtol=1.0e-10, atol=1.0e-12):
        raise RuntimeError("weighted reduced solve check failed")

    h_ff = np.array([[4.0, 1.0], [1.0, 3.0]])
    h_fgamma = np.array([[0.5], [0.25]])
    h_gammaf = h_fgamma.T
    h_gammagamma = np.array([[2.0]])
    g_f = np.array([1.0, -2.0])
    g_gamma = np.array([0.5])
    delta_f, delta_gamma = field_block_schur_direction(h_ff, h_fgamma, h_gammaf, h_gammagamma, g_f, g_gamma)
    block = np.block([[h_ff, h_fgamma], [h_gammaf, h_gammagamma]])
    direct = np.linalg.solve(block, -np.concatenate((g_f, g_gamma)))
    if not np.allclose(np.concatenate((delta_f, delta_gamma)), direct, rtol=1.0e-11, atol=1.0e-13):
        raise RuntimeError("Schur reduction check failed")

    operator = np.array([[1.0, -1.0, 0.0]])
    basis = null_space_basis(operator)
    incoming = np.zeros(3)
    coefficients = np.ones(basis.shape[1])
    direction = admissible_direction(operator, basis, coefficients)

    def metrics(value):
        fraction = np.dot(value, direction) / np.dot(direction, direction)
        return {"primary": 1.0 - 0.8 * fraction, "protected": 0.5 - 0.3 * fraction}

    result = first_joint_gate_step(
        incoming,
        operator,
        basis,
        coefficients,
        [0.1, 0.5, 1.0],
        metrics,
        "primary",
        0.1,
        {"protected": 0.4},
    )
    if (
        not result["accepted"]
        or result["decision"] != "accepted"
        or result["scale"] != 0.5
        or result["prior_candidate_count"] != 1
        or len(result["attempt_history"]) != 2
        or result["attempt_history"][0]["accepted"]
        or not result["attempt_history"][1]["accepted"]
    ):
        raise RuntimeError("first-passing gate check failed")

    reverted = first_joint_gate_step(
        incoming,
        operator,
        basis,
        coefficients,
        [0.5, 1.0],
        metrics,
        "primary",
        0.9,
        {"protected": 0.0},
    )
    if (
        reverted["accepted"]
        or reverted["decision"] != "exact_revert"
        or reverted["scale"] != 0.0
        or reverted["prior_candidate_count"] != 2
        or len(reverted["attempt_history"]) != 2
        or not np.array_equal(reverted["state"], incoming)
    ):
        raise RuntimeError("exact revert check failed")
    print("CRESCENT core checks: PASS")


if __name__ == "__main__":
    _check_core()
