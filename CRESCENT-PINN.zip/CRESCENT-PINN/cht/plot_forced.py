"""CRESCENT-PINN forced-conjugate-heat-transfer benchmark and held-physics history."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent

COLORS = ["#A9B1BA", "#6C8EBF", "#D08C60", "#1769AA"]
GREEN = "#198754"
RED = "#C83E4D"


def load_values():
    data = json.loads((HERE / "metrics.json").read_text(encoding="utf-8"))
    metric_names = [name for name in data["methods"][0] if name != "name"]
    values = np.array([[method[name] for name in metric_names] for method in data["methods"]], dtype=float)
    history = data["registered_attempt_history"]
    history_values = np.array(
        [[row["trust_before"], row["trust_after"], row["direction_norm"], row["scale"]] for row in history],
        dtype=float,
    )
    if not np.all(np.isfinite(values)) or np.any(values < 0.0):
        raise ValueError("benchmark metrics must be finite and non-negative")
    if not np.all(np.isfinite(history_values)) or np.any(history_values < 0.0):
        raise ValueError("run history must be finite and non-negative")
    return data


def clean_axis(axis, grid_axis="y"):
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(axis=grid_axis, color="#E9ECEF", linewidth=0.6)
    axis.set_axisbelow(True)


def main():
    data = load_values()
    methods = data["methods"]
    names = [row["name"] for row in methods]
    strong = methods[2]
    crescent = methods[3]

    comparison = [
        ("Velocity", "velocity_relative_l2"),
        ("Pressure", "pressure_relative_l2"),
        ("Fluid T", "fluid_temperature_relative_l2"),
        ("Solid T", "solid_temperature_relative_l2"),
        ("Worst field", "worst_field_relative_l2"),
        ("Momentum", "momentum_rms"),
        ("Fluid energy", "fluid_energy_rms"),
        ("Solid conduction", "solid_conduction_rms"),
    ]
    ratio = np.array([strong[key] / crescent[key] for _, key in comparison])
    if np.any(ratio <= 0.0):
        raise ValueError("ratio values must be positive for logarithmic display")

    constraints = [
        ("div u", "divergence_rms"),
        ("T jump", "interface_temperature_jump"),
        ("Flux jump", "interface_flux_jump"),
        ("Exterior BC", "exterior_boundary_error"),
    ]
    constraint_values = np.array([[method[key] for _, key in constraints] for method in methods])
    plotting_floor = 1.0e-19

    plt.rcParams.update({"font.family": "sans-serif", "font.size": 6.9, "axes.linewidth": 0.7, "svg.fonttype": "none", "pdf.fonttype": 42})
    figure, axes = plt.subplots(2, 2, figsize=(7.09, 5.25))
    figure.subplots_adjust(left=0.12, right=0.985, bottom=0.17, top=0.86, wspace=0.40, hspace=0.62)
    axes = axes.ravel()

    y = np.arange(len(comparison))
    axes[0].barh(y, ratio, color=GREEN, height=0.62)
    axes[0].axvline(1.0, color="#6C757D", linewidth=0.8, linestyle="--")
    axes[0].set_xscale("log")
    axes[0].set_yticks(y, [label for label, _ in comparison])
    axes[0].invert_yaxis()
    axes[0].set_xlabel("Strong control / CRESCENT-PINN")
    axes[0].set_title("Field / equation improvement factors")
    clean_axis(axes[0], "x")

    x = np.arange(len(constraints))
    width = 0.19
    for index, (name, values, color) in enumerate(zip(names, constraint_values, COLORS)):
        axes[1].bar(x + (index - 1.5) * width, np.maximum(values, plotting_floor), width, label=name, color=color)
    axes[1].set_yscale("log")
    axes[1].set_xticks(x, [label for label, _ in constraints], rotation=15, ha="right", rotation_mode="anchor")
    axes[1].set_ylabel("Constraint error / RMS")
    axes[1].set_title("Structural constraints")
    axes[1].legend(frameon=False, fontsize=5.8, ncol=2, loc="upper right")
    clean_axis(axes[1])

    timing_x = np.arange(len(names))
    timing_width = 0.34
    axes[2].bar(timing_x - timing_width / 2, [row["algorithm_seconds"] for row in methods], timing_width, label="Algorithm", color="#6C8EBF")
    axes[2].bar(timing_x + timing_width / 2, [row["active_process_seconds"] for row in methods], timing_width, label="Active process", color="#D08C60")
    axes[2].set_xticks(timing_x, names, rotation=16, ha="right", rotation_mode="anchor")
    axes[2].set_ylabel("Seconds")
    axes[2].set_title("Compute time")
    axes[2].legend(frameon=False, fontsize=6.2)
    clean_axis(axes[2])

    history = data["registered_attempt_history"]
    for index, row in enumerate(history):
        color = GREEN if row["decision"] == "accepted" else RED
        axes[3].plot([index, index], [row["trust_before"], row["trust_after"]], color=color, linewidth=1.3)
        axes[3].scatter(index, row["trust_before"], facecolor="white", edgecolor=color, s=24, zorder=3)
        axes[3].scatter(index, row["trust_after"], color=color, s=24, zorder=3)
    axes[3].set_yscale("log")
    axes[3].set_xticks(np.arange(len(history)), [f'{row["stage"]}\n{row["decision"].replace("_", " ")}' for row in history])
    axes[3].set_ylabel("Held-physics trust metric")
    axes[3].set_title("Held-physics gate history")
    clean_axis(axes[3])

    for label, axis in zip("abcd", axes):
        axis.text(-0.17, 1.08, label, transform=axis.transAxes, fontweight="bold", fontsize=8)
    figure.suptitle("Forced conjugate heat transfer", y=0.97, fontsize=10, fontweight="bold")
    figure.text(0.5, 0.035, "Zero-valued constraints are plotted at 1e-19 for log-scale visibility; exact reversion keeps the accepted state unchanged outside the joint acceptance set.", ha="center", fontsize=6.5, color="#495057")
    figure.savefig(HERE / "forced.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


if __name__ == "__main__":
    main()
