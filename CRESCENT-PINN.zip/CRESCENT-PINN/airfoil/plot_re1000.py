"""CRESCENT-PINN NACA0012 airfoil benchmark at Re = 1000."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent

CONTROL = "#A9B1BA"
CRESCENT = "#1769AA"


def load_values():
    data = json.loads((HERE / "metrics.json").read_text(encoding="utf-8"))
    fields = (
        "full_velocity_magnitude_relative_l2",
        "near_velocity_magnitude_relative_l2",
        "charged_cpu_seconds",
    )
    values = np.array([[row[field] for field in fields] for row in data["methods"]], dtype=float)
    if values.shape != (2, 3) or not np.all(np.isfinite(values)) or np.any(values <= 0.0):
        raise ValueError("benchmark values must be finite and positive")
    return data, values


def clean_axis(axis):
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(axis="y", color="#E9ECEF", linewidth=0.6)
    axis.set_axisbelow(True)


def main():
    data, values = load_values()
    names = [row["name"] for row in data["methods"]]
    titles = ("Full domain", "Near field", "Charged CPU")
    ylabels = ("Velocity-magnitude relative L2", "Velocity-magnitude relative L2", "Seconds")

    plt.rcParams.update({"font.family": "sans-serif", "font.size": 7.2, "axes.linewidth": 0.7, "svg.fonttype": "none", "pdf.fonttype": 42})
    figure, axes = plt.subplots(1, 3, figsize=(7.09, 2.55))
    figure.subplots_adjust(left=0.09, right=0.99, bottom=0.27, top=0.76, wspace=0.43)

    for index, axis in enumerate(axes):
        bars = axis.bar(np.arange(2), values[:, index], color=[CONTROL, CRESCENT], width=0.64)
        axis.set_xticks(np.arange(2), names, rotation=16, ha="right", rotation_mode="anchor")
        axis.set_ylabel(ylabels[index])
        axis.set_title(titles[index])
        clean_axis(axis)
        axis.text(-0.18, 1.08, "abc"[index], transform=axis.transAxes, fontweight="bold", fontsize=8)
        for bar, value in zip(bars, values[:, index]):
            label = f"{value:.3g}" if index < 2 else f"{value:.0f}"
            axis.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), label, ha="center", va="bottom", fontsize=6.3)

    figure.suptitle("NACA0012 airfoil, Re = 1000", y=0.95, fontsize=9.5, fontweight="bold")
    figure.text(0.5, 0.055, "Matched full-domain, near-field, and charged-CPU comparison.", ha="center", fontsize=6.6, color="#495057")
    figure.savefig(HERE / "re1000.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


if __name__ == "__main__":
    main()
